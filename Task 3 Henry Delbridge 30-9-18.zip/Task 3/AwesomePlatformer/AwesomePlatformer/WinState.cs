﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace AwesomePlatformer
{
    public class WinState: AIE.State
    {    
        SpriteFont font = null;
        float timer = 3;
        public WinState() : base()
        {
        }
        public override void Update(ContentManager content, GameTime gameTime)
        {
            if (font == null)
            {
                font = content.Load<SpriteFont>("Arial");
            }

        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.DrawString(font, "You Win!",
           new Vector2(200, 200), Color.White);
            spriteBatch.End();
        }
        public override void CleanUp()
        {
            font = null;
 
        }
    }
}
 
